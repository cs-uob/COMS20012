#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "sha512.h"

#define DEBUGHASH(name) do { debug_hash(#name, name); } while (false)
void debug_hash(char *name, uint64_t hash[STATE_LEN]);

int main(void) {
  uint64_t hashed_guess[STATE_LEN];
  uint64_t solution[STATE_LEN] = {
    0x7AEBDFC5F2B94822,
    0xB9CC57568FC71B5A,
    0x7F034712F5C2903E,
    0xB8ED3DC8194018E7,
    0xB83EEAA0EB36ECFB,
    0x8F26802B89ED0233,
    0x0EF6EA9C3E345645,
    0x84A080B39E8CED90,
  };
  uint8_t guess[16];
  bool success;

  /* Initialise the memory for the guess */
  memset(guess, 0, sizeof guess);
  
  /* Read in their guess */
  printf("Enter your password: ");
  scanf("%78s", guess);

  /* Hash it */
  sha512_hash(guess, sizeof guess, hashed_guess);

  DEBUGHASH(hashed_guess);
  DEBUGHASH(solution);
  
  /* Did you win? */
  success = (bool) (!memcmp(hashed_guess, solution, sizeof solution));
  if (success) printf("[INFO] You win :-D\n");
  else printf("[INFO] You lose!\n");
      
  return success? EXIT_SUCCESS: EXIT_FAILURE;
}

/* Helpful hash printing function. */
void debug_hash(char *name, uint64_t hash[STATE_LEN]) {
  fprintf(stderr, "\n%s = {\n", name);
  for (int i = 0; i < STATE_LEN; i++)
    fprintf(stderr, "  0x%016lX,\n", hash[i]);
  fprintf(stderr, "}\n");
}

