#pragma once
#include <stdint.h>
#include <stdio.h>

#define STATE_LEN 8 /* In words */
#define BLOCK_LEN 128 /* In bytes */
#define LENGTH_SIZE 16  // In bytes
#define ROTR64(x, n)  (((0U + (x)) << (64 - (n))) | ((x) >> (n)))  // Assumes that x is uint64_t and 0 < n < 64
#define LOADSCHEDULE(i)                                 \
  schedule[i] = (uint64_t)block[i * 8 + 0] << 56        \
    | (uint64_t)block[i * 8 + 1] << 48                  \
    | (uint64_t)block[i * 8 + 2] << 40                  \
    | (uint64_t)block[i * 8 + 3] << 32                  \
    | (uint64_t)block[i * 8 + 4] << 24                  \
    | (uint64_t)block[i * 8 + 5] << 16                  \
    | (uint64_t)block[i * 8 + 6] <<  8                  \
    | (uint64_t)block[i * 8 + 7] <<  0;
        
#define SCHEDULE(i)                                                     \
  schedule[i] = 0U + schedule[i - 16] + schedule[i - 7]                 \
    + (ROTR64(schedule[i - 15], 1) ^ ROTR64(schedule[i - 15], 8) ^ (schedule[i - 15] >> 7)) \
    + (ROTR64(schedule[i - 2], 19) ^ ROTR64(schedule[i - 2], 61) ^ (schedule[i - 2] >> 6));
        
#define ROUND(a, b, c, d, e, f, g, h, i, k)                             \
  h = 0U + h + (ROTR64(e, 14) ^ ROTR64(e, 18) ^ ROTR64(e, 41)) + (g ^ (e & (f ^ g))) + UINT64_C(k) + schedule[i]; \
  d = 0U + d + h;                                                       \
  h = 0U + h + (ROTR64(a, 28) ^ ROTR64(a, 34) ^ ROTR64(a, 39)) + ((a & (b | c)) | (b & c));

/* Hashes the message of length len and places the hash into hash */
void sha512_hash(const uint8_t message[], size_t len, uint64_t hash[static STATE_LEN]);
